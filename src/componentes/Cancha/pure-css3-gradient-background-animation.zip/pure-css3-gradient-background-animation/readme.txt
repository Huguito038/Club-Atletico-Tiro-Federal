This template / effect / code has been created by Manuel Pinto.
You can customize and check it out on its original site on the following link:
https://codepen.io/P1N2O/pen/pyBNzX

Thank you